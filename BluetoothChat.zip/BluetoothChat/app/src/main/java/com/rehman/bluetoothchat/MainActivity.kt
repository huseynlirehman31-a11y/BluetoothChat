package com.rehman.bluetoothchat

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var connectedSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    private val messages = mutableListOf<String>()
    private lateinit var messagesAdapter: ArrayAdapter<String>

    // Sabit UUID - hem sunucu hem istemci aynı UUID'yi kullanmalı
    private val appUUID: UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")

    private val permissions = arrayOf(
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.ACCESS_FINE_LOCATION
    )

    private val requestPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            Toast.makeText(this, "İzinler verildi", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Bluetooth izinleri gerekli", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adapter = android.bluetooth.BluetoothManager::class.java
        val bluetoothManager = getSystemService(android.bluetooth.BluetoothManager::class.java)
        bluetoothAdapter = bluetoothManager.adapter

        messagesAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, messages)
        findViewById<android.widget.ListView>(R.id.listMessages).adapter = messagesAdapter

        checkPermissions()

        findViewById<android.widget.Button>(R.id.btnHostServer).setOnClickListener {
            startServer()
        }

        findViewById<android.widget.Button>(R.id.btnPickDevice).setOnClickListener {
            showPairedDevices()
        }

        findViewById<android.widget.Button>(R.id.btnSend).setOnClickListener {
            val editText = findViewById<android.widget.EditText>(R.id.editMessage)
            val text = editText.text.toString()
            if (text.isNotBlank()) {
                sendMessage(text)
                editText.text.clear()
            }
        }
    }

    private fun checkPermissions() {
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            requestPermissionLauncher.launch(needed.toTypedArray())
        }
    }

    @SuppressLint("MissingPermission")
    private fun startServer() {
        addMessage("Sistem: Bağlantı bekleniyor... (diğer telefon 'Cihaz Seç'e basmalı)")
        Thread {
            try {
                val serverSocket: BluetoothServerSocket =
                    bluetoothAdapter.listenUsingRfcommWithServiceRecord("BluetoothChat", appUUID)
                val socket = serverSocket.accept() // bağlanana kadar bekler
                serverSocket.close()
                connectedSocket = socket
                setupStreams(socket)
                runOnUiThread { addMessage("Sistem: Bağlantı kuruldu!") }
                listenForMessages()
            } catch (e: IOException) {
                Log.e("BT", "Sunucu hatası", e)
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    private fun showPairedDevices() {
        val pairedDevices: Set<BluetoothDevice>? = bluetoothAdapter.bondedDevices
        if (pairedDevices.isNullOrEmpty()) {
            Toast.makeText(this, "Eşleştirilmiş cihaz yok. Önce Bluetooth ayarlarından eşleştir.", Toast.LENGTH_LONG).show()
            return
        }
        val deviceNames = pairedDevices.map { it.name ?: it.address }.toTypedArray()
        val devicesArray = pairedDevices.toTypedArray()

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Cihaz seç")
            .setItems(deviceNames) { _, which ->
                connectToDevice(devicesArray[which])
            }
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun connectToDevice(device: BluetoothDevice) {
        addMessage("Sistem: ${device.name} cihazına bağlanılıyor...")
        Thread {
            try {
                bluetoothAdapter.cancelDiscovery()
                val socket = device.createRfcommSocketToServiceRecord(appUUID)
                socket.connect()
                connectedSocket = socket
                setupStreams(socket)
                runOnUiThread { addMessage("Sistem: Bağlantı kuruldu!") }
                listenForMessages()
            } catch (e: IOException) {
                Log.e("BT", "Bağlantı hatası", e)
                runOnUiThread { addMessage("Sistem: Bağlantı başarısız - ${e.message}") }
            }
        }.start()
    }

    private fun setupStreams(socket: BluetoothSocket) {
        inputStream = socket.inputStream
        outputStream = socket.outputStream
    }

    private fun listenForMessages() {
        val buffer = ByteArray(1024)
        while (true) {
            try {
                val bytes = inputStream?.read(buffer) ?: break
                val received = String(buffer, 0, bytes)
                runOnUiThread { addMessage("Karşı taraf: $received") }
            } catch (e: IOException) {
                Log.e("BT", "Dinleme durdu", e)
                break
            }
        }
    }

    private fun sendMessage(text: String) {
        try {
            outputStream?.write(text.toByteArray())
            addMessage("Sen: $text")
        } catch (e: IOException) {
            Toast.makeText(this, "Mesaj gönderilemedi - bağlantı yok", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addMessage(msg: String) {
        messages.add(msg)
        messagesAdapter.notifyDataSetChanged()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            connectedSocket?.close()
        } catch (_: IOException) {}
    }
}
